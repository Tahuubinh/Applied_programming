int x[n+1];
    // stack<state> s;
    // //# sum of selected weights
    // int sum = 0;
    // s.push(state(1, -1));
    // while (!s.empty()){
    //     state &top = s.top();
    //     if (top.i > n){
    //         if (sum == M){
    //             for (int i = 1; i <= n; ++i){
    //                 if (x[i] == -1) cout << '-' << m[i];
    //                 if (x[i] == 1) cout << '+' << m[i];
    //             }
    //             cout << "=" << M;
    //             exit(0);
    //         }
    //         s.pop();
    //         continue;
    //     }
        
    //     //# Khử đệ quy
    //     /*****************
    //     # YOUR CODE HERE #
    //     *****************/
    // }