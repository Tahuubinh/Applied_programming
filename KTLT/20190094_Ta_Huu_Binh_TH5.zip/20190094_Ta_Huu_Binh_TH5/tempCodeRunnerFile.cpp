for (int i=1; i<=h; i++) {
        for (int j=1; j<=w; j++) {
            cout << table[i][j] << '\t';
        }
        cout << endl;
    }
    dp